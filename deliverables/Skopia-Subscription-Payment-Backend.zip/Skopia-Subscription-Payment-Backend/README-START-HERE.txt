Skopia - Subscription and Payment Management (Java backend)

Branch: feature/subscription-payment-management
Commit: 16e0e7db30259ddc30730ba3b78c8c711484ead3
GitHub: https://github.com/randillasith/Skopia/tree/feature/subscription-payment-management

Contents
- src/: complete Java backend and tests, including the shared classes FR2 needs.
- pom.xml, mvnw, mvnw.cmd and .mvn/: Maven build configuration and wrapper.
- Documentation/: FR2 API guide in Word and PDF formats.
- docs/: the original Markdown API guide and demo billing notes.
- postman/: importable subscription/payment CRUD API collection.

Backend-only build (frontend sources are not included in this ZIP)
Requirements: full JDK 17+ and network access for Maven dependencies.
On Linux/macOS, from this extracted folder:
  chmod +x mvnw
  ./mvnw -B -DskipFrontend=true clean package
On Windows:
  mvnw.cmd -B -DskipFrontend=true clean package

Start the isolated H2/demo backend on port 8081:
  ./mvnw -DskipFrontend=true -Dspring-boot.run.profiles=h2 -Dspring-boot.run.useTestClasspath=true -Dspring-boot.run.arguments=--skopia.billing.demo-enabled=true spring-boot:run
On Windows, replace ./mvnw with mvnw.cmd.
H2 is in-memory and resets on restart. Payments are simulated; no money is charged.

The documentation also describes the full repository's React workflow. For this
backend-only ZIP, always pass -DskipFrontend=true to Maven. Use the GitHub branch
for the React source and complete UI/API build.

API documentation
Read Documentation/Subscription-Payment-Management.pdf or .docx. Import the JSON
collection from postman/ and set baseUrl, viewerToken and adminToken.
Delete operations retire/cancel records; completed payments remain immutable.
No personal credentials, local .env files, dependency caches or Git metadata are
included. The repository's explicit development/test profile values are retained.

Validation of the packaged source commit
148 backend tests passed, 36 frontend tests passed, and all 26 Postman requests
were exercised against the live H2 backend. MySQL and real gateway settlement
were not verified. Archive integrity has been checked separately.
