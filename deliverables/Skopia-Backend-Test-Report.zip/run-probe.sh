#!/usr/bin/env bash
set -euo pipefail
# Run from the Skopia repository root after ./mvnw -DskipFrontend=true test.
# The probe files should be extracted into a separate report directory.
report_dir="$(cd "$(dirname "$0")" && pwd)"
./mvnw -B -ntp -DskipFrontend=true dependency:build-classpath -Dmdep.includeScope=test -Dmdep.outputFile="$report_dir/backend-classpath.txt"
probe_cp="$PWD/target/classes:$PWD/target/test-classes:$(cat "$report_dir/backend-classpath.txt")"
javac -proc:none -cp "$probe_cp" -d "$report_dir" "$report_dir/TeamBackendProbe.java"
java -cp "$report_dir:$probe_cp" TeamBackendProbe
