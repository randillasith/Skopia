import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.gp14.skopia.SkopiaApplication;
import org.gp14.skopia.advertising.AdvertisingFixture;
import org.gp14.skopia.billing.SubscriptionReminderService;
import org.gp14.skopia.model.video.AccessTier;
import org.gp14.skopia.repository.AccessTierRepository;
import org.gp14.skopia.repository.SubscriptionRepository;
import org.gp14.skopia.repository.RegisteredViewerRepository;
import org.gp14.skopia.security.TokenService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import java.net.URI;
import java.net.http.*;
import java.time.LocalDateTime;
import java.util.Map;

public class TeamBackendProbe {
    static ObjectMapper json;
    static String base;
    static final HttpClient http = HttpClient.newHttpClient();
    static JsonNode request(String method, String path, String token, Object body, int expected) throws Exception {
        HttpRequest.Builder request = HttpRequest.newBuilder(URI.create(base + path)).header("Accept", "*/*");
        if (token != null) request.header("Authorization", "Bearer " + token);
        if (body != null) request.header("Content-Type", "application/json");
        request.method(method, body == null ? HttpRequest.BodyPublishers.noBody() :
                HttpRequest.BodyPublishers.ofString(json.writeValueAsString(body)));
        HttpResponse<String> response = http.send(request.build(), HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != expected) throw new AssertionError(method + " " + path + ": " + response.statusCode() + ", expected " + expected);
        return response.body().isBlank() || !response.headers().firstValue("Content-Type").orElse("").contains("json")
                ? json.nullNode() : json.readTree(response.body());
    }
    static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }
    static Map<String,Object> card(String plan) {
        return Map.of("planName",plan,"cardNumber","4216000000000002","expiry","12/99","cardholderName","Demo Viewer");
    }

    public static void main(String[] args) throws Exception {
        try (var context = SpringApplication.run(SkopiaApplication.class,
                "--spring.profiles.active=test", "--server.port=0", "--skopia.billing.demo-enabled=true",
                "--spring.main.banner-mode=off", "--logging.level.root=ERROR",
                "--spring.jpa.properties.hibernate.generate_statistics=false")) {
            json = context.getBean(ObjectMapper.class);
            base = "http://127.0.0.1:" + ((ServletWebServerApplicationContext)context).getWebServer().getPort();
            var tx = context.getBean(TransactionTemplate.class);
            var fixture = context.getBean(AdvertisingFixture.class);
            var tokens = context.getBean(TokenService.class);
            var subscriptions = context.getBean(SubscriptionRepository.class);
            var jdbc = context.getBean(JdbcTemplate.class);
            var viewer = tx.execute(status -> fixture.viewer());
            var other = tx.execute(status -> fixture.viewer());
            var admin = tx.execute(status -> fixture.administrator());
            var officer = tx.execute(status -> fixture.officer());
            String ownerToken = tokens.issue(viewer.getId()), otherToken = tokens.issue(other.getId()),
                    adminToken = tokens.issue(admin.getId()), officerToken = tokens.issue(officer.getId());
            var category = tx.execute(status -> fixture.category("Team integration"));
            var freeVideo = tx.execute(status -> {
                var video = fixture.video("Team free video",category);
                video.setVideoUrl("https://example.invalid/free.mp4");
                return video;
            });
            var premiumVideo = tx.execute(status -> {
                var tier = new AccessTier(); tier.setTierName("PREMIUM");
                tier = context.getBean(AccessTierRepository.class).save(tier);
                var video = fixture.video("Team premium video", category);
                video.setAccessTier(tier); video.setVideoUrl("https://example.invalid/premium.mp4");
                return video;
            });

            var mappings = context.getBean("requestMappingHandlerMapping", RequestMappingHandlerMapping.class);
            check(mappings.getHandlerMethods().size() > 60, "Spring starts with unambiguous endpoint mappings (" + mappings.getHandlerMethods().size() + " mappings)");
            check(context.getBeanNamesForType(org.gp14.skopia.notification.NotificationService.class).length == 1
                    && context.getBeanNamesForType(org.gp14.skopia.complaint.NotificationService.class).length == 1,
                    "Platform notification service and complaint adapter are separate beans");
            check(request("GET", "/api/videos/" + premiumVideo.getId(), ownerToken, null, 200).get("videoUrl").isNull(),
                    "FR1 denies premium playback before FR2 checkout");

            JsonNode checkout = request("POST", "/api/billing/checkout", ownerToken, card("MONTHLY"), 201);
            long subscriptionId = checkout.at("/subscription/id").asLong(), paymentId = checkout.at("/payment/id").asLong();
            check(request("GET", "/api/videos/" + premiumVideo.getId(), ownerToken, null, 200).get("videoUrl").isTextual(),
                    "FR2 checkout grants FR1 premium playback");
            check(request("GET", "/api/auth/me", ownerToken, null, 200).get("isPremium").asBoolean(),
                    "FR6 authentication reads FR2 authoritative entitlement");
            JsonNode notifications = request("GET", "/api/notifications", ownerToken, null, 200);
            long confirmationId = -1;
            for (JsonNode notification : notifications) if ("PAYMENT_CONFIRMED".equals(notification.get("type").asText())) confirmationId = notification.get("id").asLong();
            check(confirmationId > 0, "FR2 checkout creates an FR4 payment confirmation");
            request("POST", "/api/notifications/" + confirmationId + "/read", otherToken, null, 404);
            check(request("POST", "/api/notifications/" + confirmationId + "/read", ownerToken, null, 200).get("readAt").isTextual(),
                    "FR4 notification read state is owner scoped");

            String from = LocalDateTime.now().minusDays(1).toString(), until = LocalDateTime.now().plusDays(30).toString();
            JsonNode campaign = request("POST", "/api/ad-campaigns", officerToken,
                    Map.of("campaignName","Team campaign","advertiser","Team advertiser","startDate",from,"endDate",until,"budget",0),201);
            JsonNode ad = request("POST", "/api/advertisements", officerToken,
                    Map.of("campaignId",campaign.get("id").asLong(),"adTitle","Team creative","mediaUrl","/uploads/ads/team.mp4","adType","VIDEO","adDuration",20,"clickUrl","https://example.invalid/ad"),201);
            request("POST", "/api/advertisements/" + ad.get("id").asLong() + "/targets", officerToken,
                    Map.of("videoId",freeVideo.getId(),"slotPosition","PREROLL","priority",1),201);
            request("POST", "/api/advertisements/" + ad.get("id").asLong() + "/activate", officerToken, null, 200);
            request("POST", "/api/ad-campaigns/" + campaign.get("id").asLong() + "/confirm", officerToken, null, 200);
            check(request("GET", "/api/ads/active?videoId=" + freeVideo.getId(), ownerToken, null, 200).isEmpty(),
                    "FR2 ad-free subscription suppresses FR5 delivery");
            check(request("GET", "/api/ads/active?videoId=" + freeVideo.getId(), otherToken, null, 200).size() == 1,
                    "FR5 continues to serve advertising to a non-subscriber");
            request("DELETE", "/api/billing/subscriptions/" + subscriptionId, ownerToken, null, 200);
            check(request("GET", "/api/videos/" + premiumVideo.getId(), ownerToken, null, 200).get("videoUrl").isNull(),
                    "FR2 cancellation revokes FR1 premium playback");
            check(request("GET", "/api/ads/active?videoId=" + freeVideo.getId(), ownerToken, null, 200).size() == 1,
                    "FR2 cancellation restores FR5 delivery");

            checkout = request("POST", "/api/billing/checkout", ownerToken, card("MONTHLY"),201);
            subscriptionId = checkout.at("/subscription/id").asLong(); paymentId = checkout.at("/payment/id").asLong();
            final long expiringId = subscriptionId;
            tx.executeWithoutResult(status -> {
                var subscription = subscriptions.findById(expiringId).orElseThrow();
                subscription.setEndDate(LocalDateTime.now().plusDays(2)); subscriptions.save(subscription);
            });
            context.getBean(SubscriptionReminderService.class).sendUpcomingRenewalReminders(LocalDateTime.now());
            context.getBean(SubscriptionReminderService.class).sendUpcomingRenewalReminders(LocalDateTime.now());
            notifications = request("GET", "/api/notifications", ownerToken, null,200);
            int reminders = 0;
            for (JsonNode n : notifications) if ("SUBSCRIPTION_RENEWAL".equals(n.get("type").asText())) reminders++;
            check(reminders == 1, "FR2 renewal reminder uses FR4 storage without duplicate delivery");

            long refundId = request("POST", "/api/billing/payments/" + paymentId + "/refunds", ownerToken,
                    Map.of("reason","Team integration refund"),201).get("id").asLong();
            request("POST", "/api/billing/admin/refunds/" + refundId + "/approve", ownerToken,null,403);
            request("POST", "/api/billing/admin/refunds/" + refundId + "/approve", adminToken,null,200);
            check(!request("GET", "/api/billing/status", ownerToken,null,200).get("premium").asBoolean(),
                    "FR6 refund approval revokes FR2 entitlement");
            check(request("GET", "/api/videos/" + premiumVideo.getId(), ownerToken,null,200).get("videoUrl").isNull(),
                    "FR6 refund approval revokes FR1 premium playback");
            check(request("GET", "/api/ads/active?videoId=" + freeVideo.getId(), ownerToken,null,200).size() == 1,
                    "FR6 refund approval restores FR5 advertising");
            check(request("GET", "/api/billing/payments/" + paymentId, ownerToken,null,200).get("payStatus").asText().equals("SIMULATED"),
                    "FR6 refund approval retains the FR2 immutable payment ledger");
            request("GET", "/api/billing/payments/" + paymentId + "/receipt", otherToken,null,404);
            request("GET", "/api/billing/payments/" + paymentId + "/receipt", ownerToken,null,200);

            var expiryViewer = tx.execute(status -> fixture.viewer());
            String expiryToken = tokens.issue(expiryViewer.getId());
            checkout = request("POST", "/api/billing/checkout", expiryToken,card("MONTHLY"),201);
            final long expiredId = checkout.at("/subscription/id").asLong();
            tx.executeWithoutResult(status -> {
                var subscription = subscriptions.findById(expiredId).orElseThrow();
                subscription.setEndDate(LocalDateTime.now().minusMinutes(1)); subscriptions.save(subscription);
            });
            check(request("GET", "/api/billing/status", expiryToken,null,200).get("status").asText().equals("EXPIRED"),
                    "FR2 reports actual expiry without relying on legacy premium flags");
            JsonNode identity = request("GET", "/api/auth/me", expiryToken,null,200);
            JsonNode adminUser = request("GET", "/api/admin/users/" + expiryViewer.getId(), adminToken,null,200);
            JsonNode stats = request("GET", "/api/admin/users/stats", adminToken,null,200);
            if (!identity.get("isPremium").asBoolean() && adminUser.get("isPremium").asBoolean()) {
                System.out.println("FINDING FR6 admin profile/stats retain legacy premium=true after FR2 expiry; auth=false, admin profile=true, premiumViewers=" + stats.get("premiumViewers").asLong());
            } else throw new AssertionError("Expected legacy profile mismatch was not reproduced");
            Long receiptRows = jdbc.queryForObject("select count(*) from receipts",Long.class);
            Long paymentRows = jdbc.queryForObject("select count(*) from payments",Long.class);
            System.out.println("OBSERVATION Receipt API derives receipts from payments; payments=" + paymentRows + ", legacy receipts table rows=" + receiptRows);

            tx.executeWithoutResult(status -> {
                var v = context.getBean(RegisteredViewerRepository.class).findById(expiryViewer.getId()).orElseThrow();
                v.setAccountStatus("SUSPENDED");
            });
            request("GET", "/api/billing/status", expiryToken,null,401);
            check(true,"FR6 suspension denies billing access with the existing bearer token");
            System.out.println("COMPLETE isolated cross-module probe; no persistent project database was changed");
        }
    }
}
